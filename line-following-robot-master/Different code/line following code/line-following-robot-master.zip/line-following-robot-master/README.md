# line-following-robot
video https://www.youtube.com/watch?v=3KkGIUkarwQ
$2 for 10 PCBs JLCPCB.COM
Hello friends in this video I have made a simple line following robot, 
this robot use IR sensor to detect the black line and send signal accordingly to arduino, and arduino drive motor accordingly..  
Component list 
Arduino UNO :- https://amzn.to/2DJRTnE 
IR sensor array :- https://robu.in/product/smartelex-line-sensor-module/
